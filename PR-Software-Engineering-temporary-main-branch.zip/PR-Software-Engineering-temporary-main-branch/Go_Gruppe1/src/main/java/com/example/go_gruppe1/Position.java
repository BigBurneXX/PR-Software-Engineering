package com.example.go_gruppe1;

public record Position(int row, int col) {
}
